<?php
require_once __DIR__ . '/includes/session.php';
unset($_SESSION['usuario_id'], $_SESSION['usuario_nombre']);
redirect('index.php');
