<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';

$accion = sanitize($_POST['accion'] ?? '');

if ($accion === 'login') {
    $correo   = trim($_POST['correo']   ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!$correo || !$password) {
        flash('login_error', 'Completa todos los campos.');
        redirect('index.php#registro');
    }

    $db   = getDB();
    $stmt = $db->prepare("SELECT id, nombre, password_hash FROM usuarios WHERE correo = ?");
    $stmt->execute([$correo]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user['password_hash'])) {
        flash('login_error', 'Correo o contraseña incorrectos.');
        redirect('index.php');
    }

    $_SESSION['usuario_id']     = $user['id'];
    $_SESSION['usuario_nombre'] = $user['nombre'];
    redirect('perfil.php');
}

if ($accion === 'register') {
    $nombre   = trim($_POST['nombre']   ?? '');
    $correo   = trim($_POST['correo']   ?? '');
    $password = trim($_POST['password'] ?? '');

    if (!$nombre || !$correo || !$password) {
        flash('register_error', 'Completa todos los campos.');
        redirect('index.php');
    }
    if (strlen($password) < 6) {
        flash('register_error', 'La contraseña debe tener al menos 6 caracteres.');
        redirect('index.php');
    }

    $db = getDB();
    $check = $db->prepare("SELECT id FROM usuarios WHERE correo = ?");
    $check->execute([$correo]);
    if ($check->fetch()) {
        flash('register_error', 'Ese correo ya está registrado. Inicia sesión.');
        redirect('index.php');
    }

    $hash = password_hash($password, PASSWORD_DEFAULT);
    $ins  = $db->prepare("INSERT INTO usuarios (nombre, correo, password_hash) VALUES (?,?,?)");
    $ins->execute([$nombre, $correo, $hash]);

    $uid = $db->lastInsertId();
    $_SESSION['usuario_id']     = $uid;
    $_SESSION['usuario_nombre'] = $nombre;
    redirect('perfil.php');
}

redirect('index.php');
